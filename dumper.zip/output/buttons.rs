// Generated using https://github.com/a2x/cs2-dumper
// 2025-02-28 00:17:29.654050300 UTC

#![allow(non_upper_case_globals, unused)]

pub mod cs2_dumper {
    // Module: client.dll
    pub mod buttons {
        pub const attack: usize = 0x1883710;
        pub const attack2: usize = 0x18837A0;
        pub const back: usize = 0x18839E0;
        pub const duck: usize = 0x1883CB0;
        pub const forward: usize = 0x1883950;
        pub const jump: usize = 0x1883C20;
        pub const left: usize = 0x1883A70;
        pub const lookatweapon: usize = 0x1AAC5B0;
        pub const reload: usize = 0x1883680;
        pub const right: usize = 0x1883B00;
        pub const showscores: usize = 0x1AAC490;
        pub const sprint: usize = 0x18835F0;
        pub const turnleft: usize = 0x1883830;
        pub const turnright: usize = 0x18838C0;
        pub const r#use: usize = 0x1883B90;
        pub const zoom: usize = 0x1AAC520;
    }
}
