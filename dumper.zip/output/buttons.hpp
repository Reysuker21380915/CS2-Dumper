// Generated using https://github.com/a2x/cs2-dumper
// 2025-02-28 00:17:29.654050300 UTC

#pragma once

#include <cstddef>

namespace cs2_dumper {
    // Module: client.dll
    namespace buttons {
        constexpr std::ptrdiff_t attack = 0x1883710;
        constexpr std::ptrdiff_t attack2 = 0x18837A0;
        constexpr std::ptrdiff_t back = 0x18839E0;
        constexpr std::ptrdiff_t duck = 0x1883CB0;
        constexpr std::ptrdiff_t forward = 0x1883950;
        constexpr std::ptrdiff_t jump = 0x1883C20;
        constexpr std::ptrdiff_t left = 0x1883A70;
        constexpr std::ptrdiff_t lookatweapon = 0x1AAC5B0;
        constexpr std::ptrdiff_t reload = 0x1883680;
        constexpr std::ptrdiff_t right = 0x1883B00;
        constexpr std::ptrdiff_t showscores = 0x1AAC490;
        constexpr std::ptrdiff_t sprint = 0x18835F0;
        constexpr std::ptrdiff_t turnleft = 0x1883830;
        constexpr std::ptrdiff_t turnright = 0x18838C0;
        constexpr std::ptrdiff_t use = 0x1883B90;
        constexpr std::ptrdiff_t zoom = 0x1AAC520;
    }
}
