// Generated using https://github.com/a2x/cs2-dumper
// 2025-02-28 00:17:29.654050300 UTC

namespace CS2Dumper {
    // Module: client.dll
    public static class Buttons {
        public const nint attack = 0x1883710;
        public const nint attack2 = 0x18837A0;
        public const nint back = 0x18839E0;
        public const nint duck = 0x1883CB0;
        public const nint forward = 0x1883950;
        public const nint jump = 0x1883C20;
        public const nint left = 0x1883A70;
        public const nint lookatweapon = 0x1AAC5B0;
        public const nint reload = 0x1883680;
        public const nint right = 0x1883B00;
        public const nint showscores = 0x1AAC490;
        public const nint sprint = 0x18835F0;
        public const nint turnleft = 0x1883830;
        public const nint turnright = 0x18838C0;
        public const nint use = 0x1883B90;
        public const nint zoom = 0x1AAC520;
    }
}
