// Generated using https://github.com/a2x/cs2-dumper
// 2025-02-28 00:17:29.654050300 UTC

namespace CS2Dumper.Schemas {
    // Module: networksystem.dll
    // Class count: 1
    // Enum count: 0
    public static class NetworksystemDll {
        // Parent: None
        // Field count: 1
        public static class ChangeAccessorFieldPathIndex_t {
            public const nint m_Value = 0x0; // int32
        }
    }
}
